package primer_anho;
import java.util.Scanner; 
public class PrimerAño {
 public static void main(String[] args) {
	 
	 Scanner valor = new Scanner(System.in);
	 System.out.println("Ingresa el numero de año para consultar el siglo");
	 int siglo = 0, primer_anho = 0;
	 int anho = valor.nextInt();
	 if (anho > 0) {
		 anho = anho;
	 } else {
		 System.out.println("Digito un numero negativo");
		 System.out.println("Digite un numero de valor positivo");
		 anho = valor.nextInt();
	 }
	 siglo = siglo(anho);
	 primer_anho = primer_anho(siglo);
	 System.out.println("El año digitado es " + anho + " el cual pertenece al siglo: " + siglo);
	 System.out.println("El primer año del siglo " + siglo + " es el año " + primer_anho);
	 valor.close(); 
 }
 
 static int siglo(int a) {
	 if (a % 100 == 0) {
		 return (a / 100);
	 } else {
		 return ((a / 100) + 1); 
	 }
 }
 static int primer_anho(int b) {
	 return (((b - 1) * 100) + 1);
 }
}
